//usando printf

public class Subtracao {
   int num1 = 10;
   int num2 = 5;
    public static void main(String[] args){
        Subtracao subtracao = new Subtracao();
        System.out.printf("O resultado da subtração entre %d e %d é igual a %d\n",subtracao.num1,subtracao.num2,subtracao.num1 - subtracao.num2 );
    }
}

//usando println

//public class Subtracao {
//
//    public static void main(String[] args) {
//        System.out.println(10-5);
//    }
//}


