public class Potenciacao {
}
