//usando printf

public class Soma {
    int num1 = 10;
    int num2 = 20;
    public static void main(String[] args) {
        Soma soma = new Soma();
        System.out.printf("A soma de %d e %d é %d\n", soma.num1, soma.num2, soma.num1 + soma.num2);
    }
}

//usando println

//public class Soma{
//    public static void main(String[] args){
//        System.out.println(10+20);
//    }
//}