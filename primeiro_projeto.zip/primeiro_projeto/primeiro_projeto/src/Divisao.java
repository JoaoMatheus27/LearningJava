//usando printf

//public class Divisao {
//    int num1 = 20;
//    int num2 = 10;
//    public static void main(String[] args){
//        Divisao divisao = new Divisao();
//        System.out.printf("O resultado da divisão entre %d e %d é %d", divisao.num1,divisao.num2, divisao.num1 / divisao.num2 );
//    }
//}

//usando println

public class Divisao{
    public static void main(String[] args){
        System.out.println(20/10);
    }
}

