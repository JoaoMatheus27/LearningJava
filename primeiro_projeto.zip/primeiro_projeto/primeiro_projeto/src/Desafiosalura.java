import java.util.Scanner;


//1. Crie um programa que solicite ao usuário digitar um número. Se o número for positivo, exiba "Número positivo", caso contrário, exiba "Número negativo".

/*

public class Desafiosalura {
  public static void main(String[] args) {
    System.out.println("Digite um número inteiro positivo ou inteiro negativo");
    Scanner numero = new Scanner(System.in);
    int num = numero.nextInt();
    if (num >= 1){
      System.out.println("O número digitado é positivo");
    }else if(num < 0){
      System.out.println("O número digitado é negativo");
    }else{
      System.out.println("O número digitado é neutro");
    }
  }
} */

//2. Peça ao usuário para inserir dois números inteiros. Compare os números e imprima uma mensagem indicando se são iguais, diferentes, o primeiro é maior ou o segundo é maior.


/* public class Desafiosalura{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        int numero1 = scanner.nextInt();

        System.out.print("Digite o segundo número: ");
        int numero2 = scanner.nextInt();

        if (numero1 == numero2) {
            System.out.println("Os números são iguais");
        } else if (numero1 > numero2) {
            System.out.println("O primeiro número é maior");
        } else {
            System.out.println("O segundo número é maior");
        }
    }
} */


//3.Crie um menu que oferece duas opções ao usuário: "1. Calcular área do quadrado" e "2. Calcular área do círculo". Solicite a escolha do usuário e realize o cálculo da área com base na opção selecionada.

/* public class Desafiosalura{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Escolha uma das opções abaixo :");
        System.out.println("Opção 1: Calcular área do quadrado");//quadrado: Lado X Lado
        System.out.println("Opção 2: Calcular área do círculo");// círculo: Pi X Raio²
        int escolhaUsuario = input.nextInt();//variáveis da escolha das opções do usuario
        if ( escolhaUsuario == 1){
            System.out.println("Digite o valor do Lado do quadrado");
        Double lado = input.nextDouble();//variável para o lado do quadrado inserida pelo usuário
        Double areaQ = lado * lado;//variável do cálculo do lado do quadrado
            System.out.println("O valor da área do quadrado é: "+ areaQ);
            //caso escolha o circulo
        }
        if(escolhaUsuario == 2){
            System.out.println("Digite o valor do Raio do círculo:");
            Double Raio = input.nextDouble();//variável para o raio do círculo inserido pelo usuário
        Double Raio2 = Raio * Raio;//variável para o cálculo do raio do círculo
        Double Pi = 3.14;//variável para o valor de pi
        Double areaC = Pi * Raio2;//variável para o cálculo da área do círculo
        System.out.println("O valor da área do círculo é: "+ areaC);
        }else if(escolhaUsuario != 1 || escolhaUsuario != 2){
            System.out.println("Opção selecionada não é válida");
        }
    }
}   */


//4. Crie um programa que solicite ao usuário um número e exiba a tabuada desse número de 1 a 10.

/* public class Desafiosalura{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o número para ver sua tabuada ");
        int numero = input.nextInt();
        for (int i = 1; i <= 10; i++){
            int resultado = numero * i;
            System.out.println(numero + " x " + i + " = " + resultado);
        }
    }
} */


//5.Crie um programa que solicite ao usuário a entrada de um número inteiro. Verifique se o número é par ou ímpar e exiba uma mensagem correspondente.

/*public class Desafiosalura {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num  = input.nextInt();
        System.out.println("Digite um número inteiro");

        if(num % 2 == 0){//caso o resto entre o numero digitado e 2 seja 0 ele printara que o numero é par
            System.out.println("O seu número é par");
        }else{
            System.out.println("O seu número é impar");
        }
    }
}*/

//6.Crie um programa que solicite ao usuário um número e calcule o fatorial desse número.

/* public class Desafiosalura {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Insira um número inteiro");
        int num = input.nextInt();
        int fatorial = 1;
        for (int i = 1; i <= num ; i++) {// fatorial de 5 : 5*4*3*2*1 = 120
             fatorial *= i;
            System.out.println("O valor fatorial do numero: "+ num+" é: "+ fatorial + ", "+i+", "+ num);
        }
    }
}*/
