import java.util.Scanner;

public class projetoPrincipal {
    public static void main(String[] args) {
        Scanner digite = new Scanner(System.in);
        String nome = "João Silva";
        String tipoConta = "Corrente";
        double saldoEmConta = 7500.00;
int op = 0;
        System.out.println("******************************\n  Dados iniciais do cliente:\n \n Nome: "+nome+"\n Tipo da conta: "+tipoConta+"\n Saldo inicial: "+saldoEmConta+"\n******************************");


        String menu = ("\n  Escolha uma das operações\n \n |1- Consultar saldos|\n |2- Receber valor   |\n |3- Transferir valor|\n |4- Sair            |");

        while(op != 4) {
            System.out.println(menu);
             op = digite.nextInt();
            if (op == 1) {
                System.out.println("Seu saldo atual é " + saldoEmConta);
            }else if (op == 2){
                System.out.println("Qual valor a se receber?");
                double dinRecebido = digite.nextDouble();
                double somado = saldoEmConta + dinRecebido;
                saldoEmConta += dinRecebido;
                System.out.println("O seu saldo após a adição do valor recebido é: "+ somado);
            }else if (op == 3){
                System.out.println("Quanto você deseja transferir?");
                double dinTransferido = digite.nextDouble();
                double transferido = saldoEmConta - dinTransferido;
                saldoEmConta += dinTransferido;
                System.out.println("O seu saldo após a realização da tranferência é de: "+ transferido);
                if (dinTransferido > saldoEmConta){
                    System.out.println("Saldo insuficiente");
                }
            }else if( op > 4 || op <= 0 ){
                System.out.println("Valor inválido, tente os números da tabela de operações");
            } else if (op ==4){
                System.out.println("Você saiu da página de operações do banco");
            }
        }
    }
}

